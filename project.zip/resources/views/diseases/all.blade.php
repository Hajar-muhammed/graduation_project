<!DOCTYPE html>
<html>
<head>
<title>All Diseases</title>
</head>
<body>

<h1>all diseases</h1> 
    
    @foreach ($diseases as $disease )
    
        {{-- {{ $loop->iteration }}-  --}} <a href="{{ url("diseases/show/$disease->id") }}">{{ $disease->name }} </a> <hr>
    <img src="{{ asset("storage/$disease->img") }}" width="200px" > <br>
    

        
    @endforeach
</body>
</html>