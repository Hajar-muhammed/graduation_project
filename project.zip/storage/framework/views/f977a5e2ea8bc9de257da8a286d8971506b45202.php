<!DOCTYPE html>
<html>
<head>
<title>All Diseases</title>
</head>
<body>

<h1>all diseases</h1> 
    
    <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
         <a href="<?php echo e(url("diseases/show/$disease->id")); ?>"><?php echo e($disease->name); ?> </a> <hr>
    <img src="<?php echo e(asset("storage/$disease->img")); ?>" width="200px" > <br>
    

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH E:\XAMPP\htdocs\project\project\resources\views/diseases/all.blade.php ENDPATH**/ ?>